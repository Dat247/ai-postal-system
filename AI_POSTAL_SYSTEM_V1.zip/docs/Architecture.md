# Kiến trúc hệ thống
